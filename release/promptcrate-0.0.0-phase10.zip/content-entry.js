const G=new Set(["","text","search","email","url","tel","password"]);function q(e){return e instanceof HTMLTextAreaElement?!0:e instanceof HTMLInputElement&&G.has(e.type.toLocaleLowerCase())}function K(e){return e instanceof Element?e.closest('[contenteditable="true"], [contenteditable="plaintext-only"]'):null}function _(e){return q(e)?e:K(e)}function Y(e=document){let n=null;function i(h){return!h||!C(h)?n:q(h)?(n={kind:"text-control",target:h,start:h.selectionStart??h.value.length,end:h.selectionEnd??h.value.length},n):(n={kind:"contenteditable",target:h,range:ee(e,h)},n)}function s(){const h=_(e.activeElement);return i(h)}function u(){return n&&C(n.target)?n:(n=null,s())}function c(h){i(_(h.target))}function p(){s()}function d(){s()}return e.addEventListener("focusin",c,!0),e.addEventListener("selectionchange",p),e.addEventListener("keyup",d,!0),e.addEventListener("mouseup",d,!0),{getSavedSelection:u,rememberCurrentSelection:s,destroy(){e.removeEventListener("focusin",c,!0),e.removeEventListener("selectionchange",p),e.removeEventListener("keyup",d,!0),e.removeEventListener("mouseup",d,!0)}}}function X(e,n){return!e||!C(e.target)?!1:e.kind==="text-control"?Q(e,n):J(e,n)}function Q(e,n){const{target:i}=e,s=i.value,u=R(e.start,s.length),c=R(e.end,s.length);try{i.focus(),i.value=`${s.slice(0,u)}${n}${s.slice(c)}`;const p=u+n.length;return i.setSelectionRange(p,p),H(i,n),!0}catch{return i.value=s,!1}}function J(e,n){const{target:i}=e,s=i.innerHTML,u=i.ownerDocument;try{i.focus();const c=Z(e,i,u);c.deleteContents();const p=u.createTextNode(n);c.insertNode(p),c.setStartAfter(p),c.collapse(!0);const d=u.getSelection();return d==null||d.removeAllRanges(),d==null||d.addRange(c),H(i,n),!0}catch{return i.innerHTML=s,!1}}function Z(e,n,i){if(e.range&&F(n,e.range.commonAncestorContainer))return e.range.cloneRange();const s=i.createRange();return s.selectNodeContents(n),s.collapse(!1),s}function ee(e,n){const i=e.getSelection();if(!i||i.rangeCount===0)return null;const s=i.getRangeAt(0);return F(n,s.commonAncestorContainer)?s.cloneRange():null}function F(e,n){return n===e||e.contains(n)}function C(e){return e.isConnected}function R(e,n){return Math.min(Math.max(e,0),n)}function H(e,n){const i=typeof InputEvent=="function"?new InputEvent("input",{bubbles:!0,inputType:"insertText",data:n}):new Event("input",{bubbles:!0});e.dispatchEvent(i)}const T={OPEN_PROMPT_MENU:"OPEN_PROMPT_MENU",REOPEN_MENU:"REOPEN_MENU",INSERT_RENDERED_TEMPLATE:"INSERT_RENDERED_TEMPLATE",TEMPLATES_UPDATED:"TEMPLATES_UPDATED"},te=1,w={schemaVersion:"promptCrate.schemaVersion",templates:"promptCrate.templates"},ne=[{id:"summarize-page",title:"Summarize page",body:"Summarize the key ideas from this page in concise bullets.",tags:["summary","reading"]},{id:"rewrite-clearer",title:"Rewrite clearer",body:`Rewrite the following text so it is clearer, shorter, and keeps the original meaning:

{{text}}`,tags:["writing","rewrite"]},{id:"compare-options",title:"Compare options",body:"Compare {{option_a}} and {{option_b}}. Show tradeoffs, risks, and a recommendation.",tags:["analysis","decision"]},{id:"draft-reply",title:"Draft reply",body:`Draft a warm, concise reply to this message. Tone: {{tone}}.

{{message}}`,tags:["email","writing"]},{id:"extract-actions",title:"Extract actions",body:`Extract action items, owners, and due dates from the text below:

{{notes}}`,tags:["meeting","tasks"]},{id:"debug-helper",title:"Debug helper",body:`Given this error and context, identify likely root causes and the next three checks:

{{error}}`,tags:["coding","debug"]},{id:"translate-polish",title:"Translate and polish",body:`Translate this into {{language}} and make it natural for a professional reader:

{{text}}`,tags:["translation","writing"]}];function re(e){return typeof e=="object"&&e!==null&&"type"in e&&Object.values(T).includes(e.type)}async function D(){const n=(await chrome.storage.local.get([w.schemaVersion,w.templates]))[w.templates];if(Array.isArray(n)&&n.every(ce))return n;const i=se();return await V(i),i}async function V(e){await chrome.storage.local.set({[w.schemaVersion]:te,[w.templates]:e})}function O(e){var u;const n=new Map,i=/{{\s*([^{}]+?)\s*}}/g;let s;for(;(s=i.exec(e))!==null;){const c=((u=s[1])==null?void 0:u.trim())??"",p=c.endsWith("?"),d=(p?c.slice(0,-1):c).trim();d.length>0&&!n.has(d)&&n.set(d,{name:d,required:!p})}return[...n.values()]}function oe(e,n){return e.replace(/{{\s*([^{}]+?)\s*}}/g,(i,s)=>{const u=s.trim(),c=u.endsWith("?"),p=(c?u.slice(0,-1):u).trim(),d=n[p]??"";if(!c&&d.trim().length===0)throw new Error(`Missing required variable: ${p}`);return d.length>0||c?d:i})}function ae(e,n){const i=n.trim().toLocaleLowerCase();return i.length===0?[...e]:e.filter(s=>[s.title,s.body,...s.tags].join(" ").toLocaleLowerCase().includes(i))}function N(e){return[...e].sort((n,i)=>{if(n.isFavorite!==i.isFavorite)return n.isFavorite?-1:1;const s=Date.parse(n.lastUsedAt??""),u=Date.parse(i.lastUsedAt??""),c=Number.isNaN(s)?0:s,p=Number.isNaN(u)?0:u;return c!==p?p-c:n.title.localeCompare(i.title)})}function ie(e,n=new Date().toISOString()){return{...e,lastUsedAt:n,updatedAt:n}}function se(e=new Date().toISOString()){return ne.map(n=>({...n,isFavorite:!1,createdAt:e,updatedAt:e}))}function ce(e){if(typeof e!="object"||e===null)return!1;const n=e;return typeof n.id=="string"&&typeof n.title=="string"&&typeof n.body=="string"&&Array.isArray(n.tags)&&n.tags.every(i=>typeof i=="string")&&typeof n.isFavorite=="boolean"&&typeof n.createdAt=="string"&&typeof n.updatedAt=="string"&&(n.lastUsedAt===void 0||typeof n.lastUsedAt=="string")}const U="promptcrate-menu-host",le=420;if(!window.__promptCrateContentEntryLoaded){let e=function(){const r=document.getElementById(U);if(r instanceof HTMLDivElement&&r.shadowRoot)return{host:r,shadow:r.shadowRoot};const a=document.createElement("div");a.id=U,a.style.position="fixed",a.style.zIndex="2147483647",a.style.width=`${le}px`,a.style.maxWidth="calc(100vw - 24px)",a.style.top="72px",a.style.left="50%",a.style.transform="translateX(-50%)";const o=a.attachShadow({mode:"open"});return document.documentElement.appendChild(a),{host:a,shadow:o}},n=function(r){r.style.display="block"},i=function(){t&&(t.host.style.display="none",t.shadow.textContent="",u(),t=null)},s=function(r){u(),document.addEventListener("mousedown",a,!0);function a(o){o.composedPath().includes(r)||i()}v=()=>{document.removeEventListener("mousedown",a,!0)}},u=function(){v==null||v(),v=null},c=function(r={}){if(!t)return;t.shadow.textContent="",t.shadow.append(j());const a=document.createElement("section");if(a.className="panel",a.setAttribute("role","dialog"),a.setAttribute("aria-label","PromptCrate"),t.error&&!t.savedSelection){a.append(p("PromptCrate"),S(t.error)),t.shadow.append(a);return}t.chosenTemplate?a.append(p(t.chosenTemplate.title),z()):a.append(p("PromptCrate"),d(r.focusSearch)),t.shadow.append(a)},p=function(r){const a=document.createElement("header");a.className="header";const o=document.createElement("h2");o.textContent=r;const f=document.createElement("button");return f.className="icon-button",f.type="button",f.title="Close",f.setAttribute("aria-label","Close"),f.textContent="x",f.addEventListener("click",i),a.append(o,f),a},d=function(r=!1){if(!t)return document.createElement("div");const a=document.createElement("div");a.className="list-view";const o=document.createElement("input");o.className="search",o.type="search",o.placeholder="Search templates",o.value=t.query,o.addEventListener("input",()=>{t&&(t.query=o.value,t.selectedIndex=0,c({focusSearch:!0}))}),o.addEventListener("keydown",h);const f=A(),m=document.createElement("div");return m.className="template-list",m.setAttribute("role","listbox"),f.length===0?m.append(S("No matching templates.")):f.forEach((g,x)=>{const l=document.createElement("button");l.className=x===(t==null?void 0:t.selectedIndex)?"template-item selected":"template-item",l.type="button",l.setAttribute("role","option"),l.setAttribute("aria-selected",String(x===(t==null?void 0:t.selectedIndex))),l.addEventListener("click",()=>{P(g)});const E=document.createElement("span");E.className="template-title",E.textContent=g.isFavorite?`* ${g.title}`:g.title;const y=document.createElement("span");y.className="template-body",y.textContent=g.body;const b=document.createElement("span");b.className="template-tags",b.textContent=g.tags.join(", "),l.append(E,y,b),m.append(l)}),a.append(o,m),r&&queueMicrotask(()=>{o.focus(),o.setSelectionRange(o.value.length,o.value.length)}),a},h=function(r){if(!t)return;const a=A();if(r.key==="Escape"){r.preventDefault(),i();return}if(r.key==="ArrowDown"){r.preventDefault(),t.selectedIndex=Math.min(t.selectedIndex+1,Math.max(a.length-1,0)),c({focusSearch:!0});return}if(r.key==="ArrowUp"){r.preventDefault(),t.selectedIndex=Math.max(t.selectedIndex-1,0),c({focusSearch:!0});return}r.key==="Enter"&&a[t.selectedIndex]&&(r.preventDefault(),P(a[t.selectedIndex]))},z=function(){if(!(t!=null&&t.chosenTemplate))return document.createElement("div");const r=t.chosenTemplate,a=O(r.body),o=document.createElement("form");o.className="variable-form",o.addEventListener("submit",l=>{l.preventDefault(),W(a)}),o.addEventListener("keydown",l=>{l.key==="Escape"&&(l.preventDefault(),i())});for(const l of a){const E=document.createElement("label");E.className="field";const y=document.createElement("span");y.textContent=l.required?l.name:`${l.name} (optional)`;const b=document.createElement("input");b.type="text",b.value=t.values[l.name]??"",b.required=l.required,b.addEventListener("input",()=>{t&&(t.values={...t.values,[l.name]:b.value},$(o,r))}),E.append(y,b),o.append(E)}const f=document.createElement("pre");f.className="preview",f.dataset.role="preview",f.textContent=L(r,t.values),o.append(f),t.error&&o.append(S(t.error,"error"));const m=document.createElement("div");m.className="actions";const g=document.createElement("button");g.type="button",g.textContent="Back",g.addEventListener("click",()=>{t&&(t.chosenTemplate=null,t.values={},t.error=null,c({focusSearch:!0}))});const x=document.createElement("button");return x.type="submit",x.className="primary",x.textContent="Insert",m.append(g,x),o.append(m),queueMicrotask(()=>{var l;(l=o.querySelector("input"))==null||l.focus()}),o},A=function(){return t?N(ae(t.templates,t.query)):[]},$=function(r,a){if(!t)return;const o=r.querySelector('[data-role="preview"]');o&&(o.textContent=L(a,t.values))},L=function(r,a){return r.body.replace(/{{\s*([^{}]+?)\s*}}/g,(o,f)=>{const m=f.trim(),x=(m.endsWith("?")?m.slice(0,-1):m).trim(),l=a[x]??"";return l.length>0?l:o})},S=function(r,a="info"){const o=document.createElement("p");return o.className=`notice ${a}`,o.textContent=r,o},j=function(){const r=document.createElement("style");return r.textContent=`
      :host {
        color-scheme: light;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      * {
        box-sizing: border-box;
      }

      .panel {
        width: 100%;
        max-height: min(620px, calc(100vh - 96px));
        overflow: hidden;
        color: #172026;
        background: #fffdf8;
        border: 1px solid #c9d4dc;
        border-radius: 8px;
        box-shadow: 0 18px 48px rgba(23, 32, 38, 0.18);
      }

      .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border-bottom: 1px solid #e2e8ec;
      }

      h2 {
        margin: 0;
        overflow: hidden;
        font-size: 15px;
        line-height: 1.3;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      button,
      input {
        font: inherit;
      }

      .icon-button {
        width: 28px;
        height: 28px;
        border: 0;
        border-radius: 6px;
        color: #41515d;
        background: transparent;
        cursor: pointer;
      }

      .icon-button:hover,
      .icon-button:focus-visible {
        background: #eef3f4;
        outline: none;
      }

      .list-view {
        padding: 12px;
      }

      .search {
        width: 100%;
        padding: 9px 10px;
        color: #172026;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        background: #ffffff;
      }

      .search:focus {
        border-color: #2f7f78;
        outline: 2px solid rgba(47, 127, 120, 0.2);
      }

      .template-list {
        display: grid;
        gap: 6px;
        max-height: 420px;
        margin-top: 10px;
        overflow: auto;
      }

      .template-item {
        display: grid;
        gap: 4px;
        width: 100%;
        min-height: 72px;
        padding: 10px;
        text-align: left;
        color: #172026;
        border: 1px solid transparent;
        border-radius: 7px;
        background: #f6f0e7;
        cursor: pointer;
      }

      .template-item:hover,
      .template-item.selected {
        border-color: #2f7f78;
        background: #ecf4f1;
      }

      .template-title {
        font-weight: 700;
      }

      .template-body,
      .template-tags {
        overflow: hidden;
        color: #526470;
        font-size: 12px;
        line-height: 1.35;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .variable-form {
        display: grid;
        gap: 12px;
        padding: 12px;
      }

      .field {
        display: grid;
        gap: 5px;
        color: #334650;
        font-size: 12px;
        font-weight: 700;
      }

      .field input {
        width: 100%;
        padding: 8px 10px;
        color: #172026;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        background: #ffffff;
      }

      .preview {
        max-height: 160px;
        margin: 0;
        overflow: auto;
        white-space: pre-wrap;
        color: #20313a;
        background: #f2f7f5;
        border: 1px solid #d6e2de;
        border-radius: 7px;
        padding: 10px;
      }

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }

      .actions button {
        min-width: 76px;
        padding: 8px 10px;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        color: #172026;
        background: #ffffff;
        cursor: pointer;
      }

      .actions .primary {
        color: #ffffff;
        border-color: #256b65;
        background: #2f7f78;
      }

      .notice {
        margin: 12px;
        color: #526470;
        line-height: 1.4;
      }

      .notice.error {
        color: #9f3228;
      }
    `,r};window.__promptCrateContentEntryLoaded=!0;const k=Y();let t=null;chrome.runtime.onMessage.addListener(r=>{re(r)&&((r.type===T.OPEN_PROMPT_MENU||r.type===T.REOPEN_MENU)&&M(),r.type===T.TEMPLATES_UPDATED&&t&&B())}),window.addEventListener("promptcrate:open-menu",()=>{M()});async function M(){k.rememberCurrentSelection();const{host:r,shadow:a}=e(),o=k.getSavedSelection();if(t={host:r,shadow:a,templates:[],query:"",selectedIndex:0,savedSelection:o,chosenTemplate:null,values:{},error:o?null:"Focus a text field before opening PromptCrate."},s(r),n(r),!o){c();return}t.templates=N(await D()),c({focusSearch:!0})}async function B(){t&&(t.templates=N(await D()),c())}let v=null;async function P(r){if(!t)return;if(O(r.body).length===0){await I(r,r.body);return}t.chosenTemplate=r,t.values={},t.error=null,c()}async function W(r){if(!(t!=null&&t.chosenTemplate))return;const a=r.find(o=>o.required&&((t==null?void 0:t.values[o.name])??"").trim().length===0);if(a){t.error=`Fill ${a.name} before inserting.`,c();return}try{const o=oe(t.chosenTemplate.body,t.values);await I(t.chosenTemplate,o)}catch(o){t.error=o instanceof Error?o.message:String(o),c()}}async function I(r,a){if(!t)return;if(!X(t.savedSelection,a)){t.error="PromptCrate could not insert into this field.",c();return}const f=t.templates.map(m=>m.id===r.id?ie(m):m);await V(f),i()}}
