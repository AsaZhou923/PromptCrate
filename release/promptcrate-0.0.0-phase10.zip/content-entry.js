(function(){var e=new Set([``,`text`,`search`,`email`,`url`,`tel`,`password`]);function t(t){return t instanceof HTMLTextAreaElement?!0:t instanceof HTMLInputElement&&e.has(t.type.toLocaleLowerCase())}function n(e){return e instanceof Element?e.closest(`[contenteditable="true"], [contenteditable="plaintext-only"]`):null}function r(e){return t(e)?e:n(e)}function i(e=document){let n=null;function i(r){return!r||!d(r)?n:t(r)?(n={kind:`text-control`,target:r,start:r.selectionStart??r.value.length,end:r.selectionEnd??r.value.length},n):(n={kind:`contenteditable`,target:r,range:l(e,r)},n)}function a(){return i(r(e.activeElement))}function o(){return n&&d(n.target)?n:(n=null,a())}function s(e){i(r(e.target))}function c(){a()}function u(){a()}return e.addEventListener(`focusin`,s,!0),e.addEventListener(`selectionchange`,c),e.addEventListener(`keyup`,u,!0),e.addEventListener(`mouseup`,u,!0),{getSavedSelection:o,rememberCurrentSelection:a,destroy(){e.removeEventListener(`focusin`,s,!0),e.removeEventListener(`selectionchange`,c),e.removeEventListener(`keyup`,u,!0),e.removeEventListener(`mouseup`,u,!0)}}}function a(e,t){return!e||!d(e.target)?!1:e.kind===`text-control`?o(e,t):s(e,t)}function o(e,t){let{target:n}=e,r=n.value,i=f(e.start,r.length),a=f(e.end,r.length);try{if(n.focus(),!m(n,t))return!1;p(n,`${r.slice(0,i)}${t}${r.slice(a)}`);let e=i+t.length;return n.setSelectionRange(e,e),h(n,t),!0}catch{return p(n,r),!1}}function s(e,t){let{target:n}=e,r=n.innerHTML,i=n.ownerDocument;try{n.focus();let a=c(e,n,i),o=i.getSelection();if(o?.removeAllRanges(),o?.addRange(a),!m(n,t))return!1;if(n.innerHTML!==r||g(i,t))return h(n,t),!0;a.deleteContents();let s=i.createTextNode(t);return a.insertNode(s),a.setStartAfter(s),a.collapse(!0),o?.removeAllRanges(),o?.addRange(a),h(n,t),!0}catch{return n.innerHTML=r,!1}}function c(e,t,n){if(e.range&&u(t,e.range.commonAncestorContainer))return e.range.cloneRange();let r=n.createRange();return r.selectNodeContents(t),r.collapse(!1),r}function l(e,t){let n=e.getSelection();if(!n||n.rangeCount===0)return null;let r=n.getRangeAt(0);return u(t,r.commonAncestorContainer)?r.cloneRange():null}function u(e,t){return t===e||e.contains(t)}function d(e){return e.isConnected}function f(e,t){return Math.min(Math.max(e,0),t)}function p(e,t){let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`);if(r?.set){r.set.call(e,t);return}e.value=t}function m(e,t){let n=typeof InputEvent==`function`?new InputEvent(`beforeinput`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}):new Event(`beforeinput`,{bubbles:!0,cancelable:!0});return e.dispatchEvent(n)}function h(e,t){let n=typeof InputEvent==`function`?new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t}):new Event(`input`,{bubbles:!0});e.dispatchEvent(n)}function g(e,t){try{return e.execCommand?.(`insertText`,!1,t)===!0}catch{return!1}}var _={OPEN_PROMPT_MENU:`OPEN_PROMPT_MENU`,REOPEN_MENU:`REOPEN_MENU`,INSERT_RENDERED_TEMPLATE:`INSERT_RENDERED_TEMPLATE`,TEMPLATES_UPDATED:`TEMPLATES_UPDATED`};function ee(e){return typeof e==`object`&&!!e&&`type`in e&&Object.values(_).includes(e.type)}var v={invalidTemplatesBackup:`promptCrate.invalidTemplatesBackup`,schemaVersion:`promptCrate.schemaVersion`,templates:`promptCrate.templates`},y=[{id:`summarize-page`,title:`Summarize page`,body:`Summarize the key ideas from this page in concise bullets.`,tags:[`summary`,`reading`]},{id:`rewrite-clearer`,title:`Rewrite clearer`,body:`Rewrite the following text so it is clearer, shorter, and keeps the original meaning:

{{text}}`,tags:[`writing`,`rewrite`]},{id:`compare-options`,title:`Compare options`,body:`Compare {{option_a}} and {{option_b}}. Show tradeoffs, risks, and a recommendation.`,tags:[`analysis`,`decision`]},{id:`draft-reply`,title:`Draft reply`,body:`Draft a warm, concise reply to this message. Tone: {{tone}}.

{{message}}`,tags:[`email`,`writing`]},{id:`extract-actions`,title:`Extract actions`,body:`Extract action items, owners, and due dates from the text below:

{{notes}}`,tags:[`meeting`,`tasks`]},{id:`debug-helper`,title:`Debug helper`,body:`Given this error and context, identify likely root causes and the next three checks:

{{error}}`,tags:[`coding`,`debug`]},{id:`translate-polish`,title:`Translate and polish`,body:`Translate this into {{language}} and make it natural for a professional reader:

{{text}}`,tags:[`translation`,`writing`]}];function b(e=new Date().toISOString()){return y.map(t=>({...t,isFavorite:!1,createdAt:e,updatedAt:e}))}function x(e){let t=new Map,n=/{{\s*([^{}]+?)\s*}}/g,r;for(;(r=n.exec(e))!==null;){let e=r[1]?.trim()??``,n=e.endsWith(`?`),i=(n?e.slice(0,-1):e).trim();i.length===0||t.has(i)||t.set(i,{name:i,required:!n})}return[...t.values()]}function S(e,t){return e.replace(/{{\s*([^{}]+?)\s*}}/g,(e,n)=>{let r=n.trim(),i=r.endsWith(`?`),a=(i?r.slice(0,-1):r).trim(),o=t[a]??``;if(!i&&o.trim().length===0)throw Error(`Missing required variable: ${a}`);return o.length>0||i?o:e})}function C(e){let t=[];e.id.trim().length===0&&t.push({field:`id`,message:`ID is required.`}),/^[a-z0-9][a-z0-9-_.]*$/i.test(e.id)||t.push({field:`id`,message:`ID can contain letters, numbers, dashes, underscores, and dots.`}),e.title.trim().length===0&&t.push({field:`title`,message:`Title is required.`}),e.body.trim().length===0&&t.push({field:`body`,message:`Body is required.`});let n=x(e.body).find(e=>!/^[\p{L}\p{N}_][\p{L}\p{N}_ -]*$/u.test(e.name));return n&&t.push({field:`variables`,message:`Invalid variable name: ${n.name}`}),t}function w(e,t=new Date().toISOString()){let n=e.map(e=>D(e,e.updatedAt||t)),r=n.findIndex(e=>C(e).length>0);if(r!==-1)return{ok:!1,error:`Template at index ${r+1} is invalid.`};let i=T(n);return i.length>0?{ok:!1,error:`Duplicate template id: ${i[0]}.`}:{ok:!0,templates:n}}function T(e){let t=new Set,n=new Set;for(let r of e)t.has(r.id)?n.add(r.id):t.add(r.id);return[...n]}function E(e){if(typeof e!=`object`||!e)return!1;let t=e;return typeof t.id==`string`&&typeof t.title==`string`&&typeof t.body==`string`&&Array.isArray(t.tags)&&t.tags.every(e=>typeof e==`string`)&&typeof t.isFavorite==`boolean`&&typeof t.createdAt==`string`&&typeof t.updatedAt==`string`&&(t.lastUsedAt===void 0||typeof t.lastUsedAt==`string`)}function D(e,t=new Date().toISOString()){return{...e,id:e.id.trim(),title:e.title.trim(),body:e.body,tags:O(e.tags),isFavorite:!!e.isFavorite,createdAt:e.createdAt||t,updatedAt:t}}function O(e){return[...new Set(e.map(e=>e.trim()).filter(Boolean))]}function k(e,t){let n=t.trim().toLocaleLowerCase();return n.length===0?[...e]:e.filter(e=>[e.title,e.body,...e.tags].join(` `).toLocaleLowerCase().includes(n))}function A(e){return[...e].sort((e,t)=>{if(e.isFavorite!==t.isFavorite)return e.isFavorite?-1:1;let n=Date.parse(e.lastUsedAt??``),r=Date.parse(t.lastUsedAt??``),i=Number.isNaN(n)?0:n,a=Number.isNaN(r)?0:r;return i===a?e.title.localeCompare(t.title):a-i})}function te(e,t=new Date().toISOString()){return{...e,lastUsedAt:t,updatedAt:t}}function j(){return chrome.storage.local}async function M(e=j(),t=new Date().toISOString()){let n=await e.get([v.schemaVersion,v.templates]),r=n[v.templates],i={},a;if(Array.isArray(r)&&r.every(E)){let e=w(r,t);e.ok?(a=e.templates,F(r,a)||(i[v.templates]=a)):(a=b(t),i[v.templates]=a,i[v.invalidTemplatesBackup]={reason:e.error,backedUpAt:t,templates:r})}else a=b(t),i[v.templates]=a,Array.isArray(r)&&(i[v.invalidTemplatesBackup]={reason:`Stored templates are not valid PromptCrate templates.`,backedUpAt:t,templates:r});let o={schemaVersion:1,templates:a};return n[v.schemaVersion]!==1&&(i[v.schemaVersion]=o.schemaVersion),Object.keys(i).length>0&&await e.set(i),o}async function N(e=j()){return(await M(e)).templates}async function P(e,t=j()){let n=w(e);if(!n.ok)throw Error(n.error);await t.set({[v.schemaVersion]:1,[v.templates]:n.templates})}function F(e,t){return JSON.stringify(e)===JSON.stringify(t)}var I=`promptcrate-menu-host`,L=420;if(!window.__promptCrateContentEntryLoaded){window.__promptCrateContentEntryLoaded=!0;let e=i(),t=null;chrome.runtime.onMessage.addListener(e=>{ee(e)&&((e.type===_.OPEN_PROMPT_MENU||e.type===_.REOPEN_MENU)&&n(),e.type===_.TEMPLATES_UPDATED&&t&&r())}),window.addEventListener(`promptcrate:open-menu`,()=>{n()});async function n(){e.rememberCurrentSelection();let{host:n,shadow:r}=R(),i=e.getSavedSelection();if(t={host:n,shadow:r,templates:[],query:``,selectedIndex:0,savedSelection:i,chosenTemplate:null,values:{},error:i?null:`Focus a text field before opening PromptCrate.`},V(n),z(n),!i){U();return}t.templates=A(await N()),U({focusSearch:!0})}async function r(){t&&(t.templates=A(await N()),U())}function R(){let e=document.getElementById(I);if(e instanceof HTMLDivElement&&e.shadowRoot)return{host:e,shadow:e.shadowRoot};let t=document.createElement(`div`);t.id=I,t.style.position=`fixed`,t.style.zIndex=`2147483647`,t.style.width=`${L}px`,t.style.maxWidth=`calc(100vw - 24px)`,t.style.top=`72px`,t.style.left=`50%`,t.style.transform=`translateX(-50%)`;let n=t.attachShadow({mode:`open`});return document.documentElement.appendChild(t),{host:t,shadow:n}}function z(e){e.style.display=`block`}function B(){if(!t)return;let e=t.savedSelection?.target;t.host.style.display=`none`,t.shadow.textContent=``,H(),t=null,e?.isConnected&&queueMicrotask(()=>{e.focus()})}function V(e){H(),document.addEventListener(`mousedown`,t,!0);function t(t){t.composedPath().includes(e)||B()}o=()=>{document.removeEventListener(`mousedown`,t,!0)}}let o=null;function H(){o?.(),o=null}function U(e={}){if(!t)return;t.shadow.textContent=``,t.shadow.append(re());let n=document.createElement(`section`);if(n.className=`panel`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.setAttribute(`aria-label`,`PromptCrate`),n.tabIndex=-1,n.addEventListener(`keydown`,q),t.error&&!t.savedSelection){n.append(W(`PromptCrate`),$(t.error)),t.shadow.append(n),queueMicrotask(()=>{n.focus()});return}t.chosenTemplate?n.append(W(t.chosenTemplate.title),X()):n.append(W(`PromptCrate`),G(e.focusSearch)),t.shadow.append(n)}function W(e){let t=document.createElement(`header`);t.className=`header`;let n=document.createElement(`h2`);n.textContent=e;let r=document.createElement(`button`);return r.className=`icon-button`,r.type=`button`,r.title=`Close`,r.setAttribute(`aria-label`,`Close`),r.textContent=`×`,r.addEventListener(`click`,B),t.append(n,r),t}function G(e=!1){if(!t)return document.createElement(`div`);let n=document.createElement(`div`);n.className=`list-view`;let r=document.createElement(`input`);r.className=`search`,r.type=`search`,r.setAttribute(`role`,`combobox`),r.setAttribute(`aria-controls`,`promptcrate-template-list`),r.setAttribute(`aria-expanded`,`true`),r.setAttribute(`aria-autocomplete`,`list`),r.placeholder=`Search templates`,r.value=t.query,r.addEventListener(`input`,()=>{t&&(t.query=r.value,t.selectedIndex=0,U({focusSearch:!0}))}),r.addEventListener(`keydown`,K);let i=Z(),a=i[t.selectedIndex]?`promptcrate-template-option-${t.selectedIndex}`:null;a&&r.setAttribute(`aria-activedescendant`,a);let o=document.createElement(`div`);return o.id=`promptcrate-template-list`,o.className=`template-list`,o.setAttribute(`role`,`listbox`),o.setAttribute(`aria-label`,`Templates`),i.length===0?o.append($(`No matching templates.`)):i.forEach((e,n)=>{let r=document.createElement(`div`);r.id=`promptcrate-template-option-${n}`,r.className=n===t?.selectedIndex?`template-item selected`:`template-item`,r.tabIndex=-1,r.setAttribute(`role`,`option`),r.setAttribute(`aria-selected`,String(n===t?.selectedIndex)),r.addEventListener(`mousedown`,e=>{e.preventDefault()}),r.addEventListener(`click`,()=>{s(e)});let i=document.createElement(`span`);i.className=`template-title`,i.textContent=e.isFavorite?`* ${e.title}`:e.title;let a=document.createElement(`span`);a.className=`template-body`,a.textContent=e.body;let c=document.createElement(`span`);c.className=`template-tags`,c.textContent=e.tags.join(`, `),r.append(i,a,c),o.append(r)}),n.append(r,o),e&&queueMicrotask(()=>{r.focus(),r.setSelectionRange(r.value.length,r.value.length)}),n}function K(e){if(!t)return;let n=Z();if(e.key===`Escape`){e.preventDefault(),B();return}if(e.key===`ArrowDown`){e.preventDefault(),t.selectedIndex=Math.min(t.selectedIndex+1,Math.max(n.length-1,0)),U({focusSearch:!0});return}if(e.key===`ArrowUp`){e.preventDefault(),t.selectedIndex=Math.max(t.selectedIndex-1,0),U({focusSearch:!0});return}e.key===`Enter`&&n[t.selectedIndex]&&(e.preventDefault(),s(n[t.selectedIndex]))}function q(e){if(t){if(e.key===`Escape`){e.preventDefault(),B();return}e.key===`Tab`&&J(e)}}function J(e){if(!t)return;let n=Y(t.shadow);if(n.length===0){e.preventDefault();return}let r=n[0],i=n[n.length-1],a=t.shadow.activeElement;if(e.shiftKey&&a===r){e.preventDefault(),i.focus();return}!e.shiftKey&&a===i&&(e.preventDefault(),r.focus())}function Y(e){return[...e.querySelectorAll(`button, input, textarea, select, [href], [tabindex]:not([tabindex="-1"])`)].filter(e=>{let t=window.getComputedStyle(e);return!e.hasAttribute(`disabled`)&&e.getAttribute(`aria-hidden`)!==`true`&&t.display!==`none`&&t.visibility!==`hidden`})}async function s(e){if(t){if(x(e.body).length===0){await l(e,e.body);return}t.chosenTemplate=e,t.values={},t.error=null,U()}}function X(){if(!t?.chosenTemplate)return document.createElement(`div`);let e=t.chosenTemplate,n=x(e.body),r=document.createElement(`form`);r.className=`variable-form`,r.addEventListener(`submit`,e=>{e.preventDefault(),c(n)}),r.addEventListener(`keydown`,e=>{e.key===`Escape`&&(e.preventDefault(),B())});for(let i of n){let n=document.createElement(`label`);n.className=`field`;let a=document.createElement(`span`);a.textContent=i.required?i.name:`${i.name} (optional)`;let o=document.createElement(`input`);o.type=`text`,o.value=t.values[i.name]??``,o.required=i.required,o.addEventListener(`input`,()=>{t&&(t.values={...t.values,[i.name]:o.value},ne(r,e))}),n.append(a,o),r.append(n)}let i=document.createElement(`pre`);i.className=`preview`,i.dataset.role=`preview`,i.textContent=Q(e,t.values),r.append(i),t.error&&r.append($(t.error,`error`));let a=document.createElement(`div`);a.className=`actions`;let o=document.createElement(`button`);o.type=`button`,o.textContent=`Back`,o.addEventListener(`click`,()=>{t&&(t.chosenTemplate=null,t.values={},t.error=null,U({focusSearch:!0}))});let s=document.createElement(`button`);return s.type=`submit`,s.className=`primary`,s.textContent=`Insert`,a.append(o,s),r.append(a),queueMicrotask(()=>{r.querySelector(`input`)?.focus()}),r}async function c(e){if(!t?.chosenTemplate)return;let n=e.find(e=>e.required&&(t?.values[e.name]??``).trim().length===0);if(n){t.error=`Fill ${n.name} before inserting.`,U();return}try{let e=S(t.chosenTemplate.body,t.values);await l(t.chosenTemplate,e)}catch(e){t.error=e instanceof Error?e.message:String(e),U()}}async function l(e,n){if(!t)return;if(!a(t.savedSelection,n)){t.error=`PromptCrate could not insert into this field.`,U();return}let r=(await N()).map(t=>t.id===e.id?te(t):t);await P(r),t.templates=A(r),B()}function Z(){return t?A(k(t.templates,t.query)):[]}function ne(e,n){if(!t)return;let r=e.querySelector(`[data-role="preview"]`);r&&(r.textContent=Q(n,t.values))}function Q(e,t){return e.body.replace(/{{\s*([^{}]+?)\s*}}/g,(e,n)=>{let r=n.trim(),i=t[(r.endsWith(`?`)?r.slice(0,-1):r).trim()]??``;return i.length>0?i:e})}function $(e,t=`info`){let n=document.createElement(`p`);return n.className=`notice ${t}`,n.textContent=e,n}function re(){let e=document.createElement(`style`);return e.textContent=`
      :host {
        color-scheme: light;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      * {
        box-sizing: border-box;
      }

      .panel {
        width: 100%;
        max-height: min(620px, calc(100vh - 96px));
        overflow: hidden;
        color: #172026;
        background: #fffdf8;
        border: 1px solid #c9d4dc;
        border-radius: 8px;
        box-shadow: 0 18px 48px rgba(23, 32, 38, 0.18);
      }

      .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border-bottom: 1px solid #e2e8ec;
      }

      h2 {
        margin: 0;
        overflow: hidden;
        font-size: 15px;
        line-height: 1.3;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      button,
      input {
        font: inherit;
      }

      .icon-button {
        width: 28px;
        height: 28px;
        border: 0;
        border-radius: 6px;
        color: #41515d;
        background: transparent;
        cursor: pointer;
      }

      .icon-button:hover,
      .icon-button:focus-visible {
        background: #eef3f4;
        outline: none;
      }

      .list-view {
        padding: 12px;
      }

      .search {
        width: 100%;
        padding: 9px 10px;
        color: #172026;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        background: #ffffff;
      }

      .search:focus {
        border-color: #2f7f78;
        outline: 2px solid rgba(47, 127, 120, 0.2);
      }

      .template-list {
        display: grid;
        gap: 6px;
        max-height: 420px;
        margin-top: 10px;
        overflow: auto;
      }

      .template-item {
        display: grid;
        gap: 4px;
        width: 100%;
        min-height: 72px;
        padding: 10px;
        text-align: left;
        color: #172026;
        border: 1px solid transparent;
        border-radius: 7px;
        background: #f6f0e7;
        cursor: pointer;
      }

      .template-item:hover,
      .template-item.selected {
        border-color: #2f7f78;
        background: #ecf4f1;
      }

      .template-title {
        font-weight: 700;
      }

      .template-body,
      .template-tags {
        overflow: hidden;
        color: #526470;
        font-size: 12px;
        line-height: 1.35;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .variable-form {
        display: grid;
        gap: 12px;
        padding: 12px;
      }

      .field {
        display: grid;
        gap: 5px;
        color: #334650;
        font-size: 12px;
        font-weight: 700;
      }

      .field input {
        width: 100%;
        padding: 8px 10px;
        color: #172026;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        background: #ffffff;
      }

      .preview {
        max-height: 160px;
        margin: 0;
        overflow: auto;
        white-space: pre-wrap;
        color: #20313a;
        background: #f2f7f5;
        border: 1px solid #d6e2de;
        border-radius: 7px;
        padding: 10px;
      }

      .actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }

      .actions button {
        min-width: 76px;
        padding: 8px 10px;
        border: 1px solid #b8c6cf;
        border-radius: 7px;
        color: #172026;
        background: #ffffff;
        cursor: pointer;
      }

      .actions .primary {
        color: #ffffff;
        border-color: #256b65;
        background: #2f7f78;
      }

      .notice {
        margin: 12px;
        color: #526470;
        line-height: 1.4;
      }

      .notice.error {
        color: #9f3228;
      }
    `,e}}})();